package edu.upenn.cis350.status.client;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		StatusDataSource source1 = new RemoteDataSource("localhost", 12345);
		StatusDataSource source2 = new RemoteDataSource("localhost", 23456);
		
		List<StatusDataSource> list = new ArrayList<StatusDataSource>();
		list.add(source1);
		list.add(source2);
		
		StatusProcessor sp = new StatusProcessor(list);
		CommandLineUI clui = new CommandLineUI(sp);
		clui.start();		
	}
}
