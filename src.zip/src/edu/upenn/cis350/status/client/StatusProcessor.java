package edu.upenn.cis350.status.client;

import java.util.*;
import edu.upenn.cis350.status.common.*;

public class StatusProcessor {
	Map<Integer, Status> map = new HashMap<Integer, Status>();;
	List<StatusDataSource> sources;
	
	public StatusProcessor(List<StatusDataSource> list) {
		this.sources = list;
	}
	
	public Status getStatus(int i) {
		for (StatusDataSource s : sources) {
			Status updated = s.requestStatus(i);
			Status old = map.get(i);
			if (!updated.status.equals(old.status)) {
				map.put(i, updated);
				return updated;
			}
		}
		return null;
	}

}
