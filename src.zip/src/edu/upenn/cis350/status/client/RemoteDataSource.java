package edu.upenn.cis350.status.client;

import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

import edu.upenn.cis350.status.common.Status;

public class RemoteDataSource implements StatusDataSource{
	String host;
	int port;
	
	public RemoteDataSource(String host, int port) {
		this.host = host;
		this.port = port;
	}
	
	public Status requestStatus(int id) {
		try {
			// Set up Servers and Sockets and stuff
			ServerSocket ss = new ServerSocket(23456);
			Socket socket = ss.accept();
			Scanner in = new Scanner(socket.getInputStream());
			PrintWriter out = new PrintWriter(socket.getOutputStream());
			// Find Status
			Status status = null;
			// send id 
			out.println(id);
			// read status
			if(in.nextInt() == 0) {
				String temp = in.nextLine();
				status = new Status(id, temp);
			}
			ss.close();
			in.close();
			return status;
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
