package edu.upenn.cis350.status.client;

import java.util.Scanner;
import edu.upenn.cis350.status.common.*;

public class CommandLineUI {
	StatusProcessor processor;
	
	public CommandLineUI(StatusProcessor p) {
		processor = p;
	}
	
	public void start() {
		while (true) {
			System.out.println("Enter the person's ID: ");
			Scanner in = new Scanner(System.in);
			int input = in.nextInt();
			
			try {
				Status status = processor.getStatus(input);
				if (status == null) {
					System.out.println("No status for id " + input);
				}
				else {
					System.out.println("The status is " + status.status + " as of " + status.updated);
				}
			}
			catch (Exception e) {
				System.out.println("Could not get status for : " + input + "; " + e.getMessage());
				e.printStackTrace();
			}
		}
	}
}
