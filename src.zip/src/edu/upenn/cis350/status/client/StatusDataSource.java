package edu.upenn.cis350.status.client;

import edu.upenn.cis350.status.common.Status;

public interface StatusDataSource {
	
	public Status requestStatus(int i);
	
}
