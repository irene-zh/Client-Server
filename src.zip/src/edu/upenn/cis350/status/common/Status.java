package edu.upenn.cis350.status.common;

import java.io.Serializable;
import java.util.Date;

public class Status implements Serializable {
	
	public int id;
	public String status;
	public Date updated;
	
	public Status(int id, String status) {
		this.id = id;
		this.status = status;
		updated = new Date();
	}
	
	public Status(int id, String status, String dateString) {
		this.id = id;
		this.status = status;
		updated = new Date(dateString);
	}
 	

}
