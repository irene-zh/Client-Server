package edu.upenn.cis350.status.server;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

import edu.upenn.cis350.status.common.Status;

public class Server {
	int socketNumber;
	
	public Server(int number) {
		this.socketNumber = number;
	}
	
	public void runServer() {
		try {
			// Set up Servers and Sockets and stuff
			ServerSocket ss = new ServerSocket(23456);
			Socket socket = ss.accept();
			Scanner in = new Scanner(socket.getInputStream());
			PrintWriter out = new PrintWriter(socket.getOutputStream());
			// Find Status
			StatusFinder status = new StatusFinder(new FakeDataSource());
			// LOOP
			while(true) {
				int data = in.nextInt();
				out.println("Enter the person's ID: \n");
				Status s = status.getStatus(data);
				if (s != null) {
					out.println("0\n");
					out.println(s.status+"\n");
				}
				else {
					out.println("-1\n");
				}
				out.flush();
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
