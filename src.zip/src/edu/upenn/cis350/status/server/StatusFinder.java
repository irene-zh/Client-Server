package edu.upenn.cis350.status.server;

import java.util.HashMap;
import java.util.Map;

import edu.upenn.cis350.status.common.Status;

public class StatusFinder {
	
	private DataSource ds;
	private Map<Integer, Status> map;
	
	public StatusFinder(DataSource d) {
		ds = d;
		map = new HashMap<Integer, Status>();
	}

	public Status getStatus(int input) {
		
		try {
			// first see if it's in the dataset
			Status[] all = ds.getData();
			for (Status s : all) {
				if (s.id == input) {
					map.put(input, s);
					return s;
				}
			}
			// didn't find it, see if we have a cached version
			return map.get(input);
		}
		catch (Exception e) {
			// error occurred reading from DataSource
			// see if it's in cache
			return map.get(input);
		}


	}

}
