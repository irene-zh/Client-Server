package edu.upenn.cis350.status.server;

import edu.upenn.cis350.status.common.Status;

public interface DataSource {
	
	public Status[] getData() throws Exception;

}
