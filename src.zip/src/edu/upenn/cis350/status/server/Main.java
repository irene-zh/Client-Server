package edu.upenn.cis350.status.server;
import java.util.*;

public class Main {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int serverNum = scanner.nextInt();
		
		Server s = new Server(serverNum);
		s.runServer();	
	}

}
