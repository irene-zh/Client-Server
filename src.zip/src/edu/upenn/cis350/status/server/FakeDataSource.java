package edu.upenn.cis350.status.server;

import edu.upenn.cis350.status.common.Status;

public class FakeDataSource implements DataSource {
	

	public Status[] getData() throws Exception {
		Status s1 = new Status(123456789, "safe");
		Status s2 = new Status(987654321, "missing");
		Status s3 = new Status(111111111, "deceased");
		Status s4 = new Status(222222222, "hospitalized");
		return new Status[]{s1, s2, s3, s4};
	}

}
